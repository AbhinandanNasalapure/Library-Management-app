package com.library.nl.library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
